

public class Main {
    public static void main(String[] args) {
        ManageOfRequest manageOfRequest = new ManageOfRequest();
        manageOfRequest.Requests();
    }
}

