package CarStore.interfaces;

public interface ICar {
    String techInspection();
}
